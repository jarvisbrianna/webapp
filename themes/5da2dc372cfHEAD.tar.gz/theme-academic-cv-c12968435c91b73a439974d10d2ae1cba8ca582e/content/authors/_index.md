---
# To publish author profile pages, remove all the `build` and `cascade` settings below.
build:
  render: never
cascade:
  build:
    render: never
    list: always
---
