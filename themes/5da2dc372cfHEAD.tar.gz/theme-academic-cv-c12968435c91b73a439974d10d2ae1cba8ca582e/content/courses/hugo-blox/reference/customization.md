---
title: Customizing Hugo
linkTitle: Customization
weight: 1
---

View the full docs at https://docs.hugoblox.com/getting-started/customize/
